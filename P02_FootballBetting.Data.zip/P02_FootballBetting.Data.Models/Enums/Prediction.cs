﻿namespace P02_FootballBetting.Data.Models.Enums;
//Enums are not entities in the DB
//Enumerations are string representations of int values
public enum Prediction
{
    Draw = 0,
    Win = 1,
    Lose = 2   

}
