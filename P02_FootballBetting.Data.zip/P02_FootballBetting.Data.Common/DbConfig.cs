﻿namespace P02_FootballBetting.Data.Common
{
    public static class DbConfig
    {
        public const string ConnectionsString = @"Server=DESKTOP-A00DVP1\SQLEXPRESS;Database=Bet388;Integrated Security=True;Encrypt=False";
    }
}