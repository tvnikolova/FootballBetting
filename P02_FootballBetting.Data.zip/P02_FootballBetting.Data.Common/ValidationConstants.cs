﻿namespace P02_FootballBetting.Data.Common;

public class ValidationConstants
{

    public const int TeamNameMaxLength = 50;
    public const int LogourlMaxLength = 2048;
    public const int InitialsMaxLength = 4;

    //Color
    public const int ColorNameMaxLength = 20;
    //Town
    public const int TownNameMaxLength = 60;

    //Country

    public const int CountryNameMaxLength = 60;
    //Player
    public const int PlayerNameMaxLength = 100;
    //Position
    public const int PositionNameMaxLength = 50;
    //Game
    public const int GameResultMaxLength = 7;
    //User
    public const int UsersUserNameMaxLength = 40;
    public const int PasswordMaxLength = 256;
    public const int EmailMaxLength = 256;
    public const int UserNameMaxLength = 100;
}


